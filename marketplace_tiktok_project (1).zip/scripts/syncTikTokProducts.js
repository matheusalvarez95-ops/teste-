// Demo sync script - inserts a fake product if DB is configured
import { query } from '../lib/db'
async function run(){
  try{
    const fake = {
      title: 'Mini Ventilador Portátil',
      description: 'Ventilador USB pequeno e potente',
      images: ['https://via.placeholder.com/600x400'],
      categories: ['Casa','Eletrônicos'],
      price: 19.9,
      tiktok_score: 95
    }
    await query(
      `INSERT INTO products(title, description, images, categories, price, tiktok_score, last_synced) VALUES($1,$2,$3,$4,$5,$6,now())`,
      [fake.title, fake.description, JSON.stringify(fake.images), fake.categories, fake.price, fake.tiktok_score]
    )
    console.log('Inserted demo product')
  }catch(err){ console.error(err) }
}
run()
