CREATE TABLE users (
  id SERIAL PRIMARY KEY,
  name TEXT,
  email TEXT UNIQUE NOT NULL,
  phone TEXT,
  address JSONB,
  created_at TIMESTAMP DEFAULT now()
);
CREATE TABLE suppliers (
  id SERIAL PRIMARY KEY,
  name TEXT NOT NULL,
  api_base TEXT,
  auth JSONB,
  lead_time_days INT,
  active BOOLEAN DEFAULT true
);
CREATE TABLE products (
  id SERIAL PRIMARY KEY,
  title TEXT,
  description TEXT,
  images JSONB,
  categories TEXT[],
  price NUMERIC(10,2),
  currency TEXT DEFAULT 'USD',
  supplier_data JSONB,
  tiktok_score NUMERIC,
  last_synced TIMESTAMP
);
CREATE TABLE supplier_products (
  id SERIAL PRIMARY KEY,
  supplier_id INT REFERENCES suppliers(id),
  supplier_sku TEXT,
  product_id INT REFERENCES products(id),
  price NUMERIC(10,2),
  stock INT,
  shipping_info JSONB
);
CREATE TABLE orders (
  id SERIAL PRIMARY KEY,
  user_id INT REFERENCES users(id),
  total_amount NUMERIC(12,2),
  currency TEXT,
  status TEXT,
  payment_provider TEXT,
  payment_id TEXT,
  supplier_orders JSONB,
  shipping_address JSONB,
  created_at TIMESTAMP DEFAULT now(),
  updated_at TIMESTAMP DEFAULT now()
);
CREATE TABLE order_items (
  id SERIAL PRIMARY KEY,
  order_id INT REFERENCES orders(id),
  product_id INT REFERENCES products(id),
  quantity INT,
  unit_price NUMERIC(10,2),
  supplier_id INT REFERENCES suppliers(id),
  supplier_order_id TEXT
);
CREATE TABLE webhooks_log (
  id SERIAL PRIMARY KEY,
  provider TEXT,
  payload JSONB,
  received_at TIMESTAMP DEFAULT now(),
  processed BOOLEAN DEFAULT false
);
