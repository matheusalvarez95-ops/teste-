import useSWR from 'swr'
const fetcher = url => fetch(url).then(r => r.json())
export default function Home(){ 
  const { data } = useSWR('/api/products', fetcher)
  const products = data?.products || []
  return (
    <main style={{fontFamily:'Inter, system-ui, -apple-system, sans-serif', padding:20}}>
      <h1 style={{fontSize:28}}>Tendências do TikTok</h1>
      <p style={{color:'#666'}}>Produtos virais atualizados automaticamente</p>
      <div style={{display:'grid', gridTemplateColumns:'repeat(auto-fit,minmax(240px,1fr))', gap:16, marginTop:16}}>
        {products.map(p => (
          <article key={p.id} style={{border:'1px solid #eee', borderRadius:8, padding:12, background:'#fff'}}>
            <img src={p.images?.[0] || '/placeholder.png'} alt={p.title} style={{width:'100%', height:160, objectFit:'cover', borderRadius:6}} />
            <h2 style={{fontSize:16, marginTop:8}}>{p.title}</h2>
            <p style={{color:'#111', fontWeight:600}}>${p.price}</p>
            <a href={'/product/'+p.id} style={{display:'inline-block', marginTop:8, color:'#06f'}}>Ver produto</a>
          </article>
        ))}
      </div>
    </main>
  )
}
