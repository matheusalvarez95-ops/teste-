import { query } from '../../lib/db'
export default async function handler(req,res){
  const result = await query('SELECT id,title,price,images FROM products ORDER BY tiktok_score DESC LIMIT 20',[])
  res.json({ products: result.rows })
}
