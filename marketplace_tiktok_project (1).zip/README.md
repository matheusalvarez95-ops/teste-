# Marketplace TikTok Viral — Projeto Pronto (Esqueleto)

Conteúdo: esqueleto pronto em Next.js com integrações fictícias, worker de fulfillment, SQL inicial e página de preview estática.

Como usar:
1. Descompacte o arquivo.
2. Configure variáveis em `.env` (veja `.env.example`).
3. Rode `npm install` dentro da pasta e depois `npm run dev` para iniciar o Next.js (requer Node.js).
4. Para visualizar uma prévia estática rápida, abra `preview/preview.html` no navegador.
